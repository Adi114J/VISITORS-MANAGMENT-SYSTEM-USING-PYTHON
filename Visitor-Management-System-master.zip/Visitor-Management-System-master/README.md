# Visitor-Management System

This is a Visitor Management Web-App that can serve in offices for keeping a database of the visitors visiting the office everyday along with 
the time that they spend with the Host. It also sends an E-mail as well as SMS to the Host whenever a new visior checks in or a visitor 
checks out.

Tech-Stack Used:
1. HTML
2. CSS
3. Javascript
4. Bootstrap
5. Python 
6. Django
7. API

This project was developed during the Winter Of Code 2.0 organised by the Microsoft Student Technical Club(MSTC), DAIICT and out of the three winning projects, this was one of them.
